window.onload = function () {
	var modal = document.getElementById('Modal');
	var restart2 = document.getElementById('Restart2');
	var restart1 = document.getElementById('Restart1');
	var loading = document.getElementById('Loading');
	var int;

	function send(page, data, callback) {
		var req = new XMLHttpRequest();
		req.open("POST", page, true);
		req.setRequestHeader('Content-Type', 'application/json');
		req.addEventListener("load", function () {
			if (req.status < 400) {
				callback(req.responseText);
			} else {
				callback(req.status);
			}
		});
		req.send(JSON.stringify(data));
	}

		function nav() {
			var x = document.getElementById("myTopnav");
			if (x.classList.contains("res")) {
				x.classList.remove('res');
			} else {
				x.classList.add('res');
			}
		}

	function id(val) {
		return document.getElementById(val).value
	}

	function check_sel(val) {
		var s = document.getElementById(val);
		for (var i = 0; i < s.options.length; i++) {
			if (s.options[i].selected) {
				return s.options[i].value
			}
		}
	}

	function logout() {
		document.cookie = "id=";
		location.href = '/login.html';
	}

	function input(val) {
		var arr = ["mqtt_time", "mqtt_server", "mqtt_port", "mqtt_login", "mqtt_pass"];
		for (var i = 0; i < arr.length; i++) {
			document.getElementById(arr[i]).disabled = val;
			if (val) {document.getElementById(arr[i]).value = "";}
		}
	}

if (check_sel("mqtt") == "OFF") {
  input(true);
}

	function save() {
		var data = {init: "save"};
		var stop=false
		var arr = ["mu","md","ss1","ss2","bg","dg","dov","dcv","ob","odt","cnt","nm","wifi_id", "wifi_pass", "wifi_phy", "wifi_mode", "auth_pass", "auth_login", "auth", "mqtt_port", "mqtt_pass", "mqtt_server", "mqtt", "mqtt_login", "mqtt_time"];
		arr.forEach(function (item, i, arr) {
			console.log("item: "+item);
			if (item == "wifi_mode" || item == "auth" || item == "mqtt") {
				data[item] = check_sel(item)
				}
				else {
					if (check_sel("mqtt") == "ON") {
						if (item == "mqtt_time" || item == "mqtt_server" || item == "mqtt_port") {
							if (id(item) !== "") {
								document.getElementById(item).style.borderColor = "#bbb";
							}else{
								stop=true;
								document.getElementById(item).style.borderColor = "red";
							}
						}
						data[item] = id(item)
					}else{
						data[item] = id(item)
					}
				}
		});
		if (stop){ modal.style.display = "none"; location.href = "/"; return;}
		if (check_sel("wifi_mode") == "OFF") {
			var w = confirm("Внимание!!! Безжичната връзка ще бъде деактивирана.");
			if (!w) {
				return
			}
		}
		send("web_control.lc", data, function (res) {
			if (res == "true") {
				send("web_control.lc", {
					init: "reboot"
				}, function (res) {
					modal.style.opacity = "0";
					modal.style.display = "none";
					restart1.style.opacity = "1";
					restart1.style.display = "block";
				    var timeleft = 15;
					var downloadTimer = setInterval(function(){
					timeleft--;
					document.getElementById("countdowntimer").textContent = timeleft;
					if(timeleft <= 0){
						clearInterval(downloadTimer);
						location.href = "/";}
					},1000);
				});
			}
		})
	}
	var x = ["|", "(|", "((|", "(((|", "((((|"];
	var y = 0;

	function ani() {
		if (y > 4) {
			y = 0
		}
		document.getElementById('search').value = x[y];
		y = y + 1
	}

	function scan() {
		int = setInterval(ani, 200);
		send("web_control.lc", {
			init: "scan"
		}, function (res) {});

		setTimeout(function () {
			var a = document.getElementById('list');
			send("web_control.lc", {
				init: "get"
			}, function (res) {
				if (res) {
					clearInterval(int);
					y = 0;
					document.getElementById('search').value = "Списък";
					try {
						var j = JSON.parse(res);
						for (var i = 0; i < j.length; i++) {
							if (i == 0) {
								a.innerHTML = '<li id="' + j[i].sd + '"><b>' + j[i].sd + '</b> rssi : ' + j[i].ri + ' channel : ' + j[i].cl + '</li>';
							} else {
								a.innerHTML += '<li id="' + j[i].sd + '"><b>' + j[i].sd + '</b> rssi : ' + j[i].ri + ' channel : ' + j[i].cl + '</li>';
							}
						}
					} catch (e) {
						a.innerHTML = '<li>Няма намерени мрежи</li>';
					}
					a.style.display = 'block';
				}
			});
		}, 5000);
	}
	function reboot() {
		var data = {init: "reboot"};
		send("web_control.lc", data, function (res) {
			if (res == "true")
				{
					restart2.style.opacity = "0";
					restart2.style.display = "none";
					restart1.style.opacity = "1";
					restart1.style.display = "block";
				    var timeleft = 15;
					var downloadTimer = setInterval(function(){
					timeleft--;
					document.getElementById("countdowntimer").textContent = timeleft;
					if(timeleft <= 0){
						clearInterval(downloadTimer);
						location.href = "/";}
					},1000);

				}
		})
	}
	document.body.addEventListener("click", function (event) {
		var a = document.getElementById('list');
		//alert(event.target.id)
		if (event.target.id == "search") {
			scan();
		} else if (event.target.id == "btn_nav") {
			nav();
		} else if (event.target.id == "btn_exit") {
			logout();
		} else if (event.target.id == "btn_save") {
			modal.style.opacity = "1";
			modal.style.display = "block";
		} else if (event.target.id == "btn_restart") {
			restart2.style.opacity = "1";
			restart2.style.display = "block";
		} else if (event.target.id == "distag") {
			loading.style.opacity = "1";
			loading.style.display = "block";
		} else if (event.target.id == "restart_c") {
			restart2.style.opacity = "0";
			setTimeout(function () {
				restart2.style.display = "none";
			}, 600);
		} else if (event.target.id == "restart_m") {
			reboot()
		} else if (event.target.id == "close_m") {
			modal.style.opacity = "0";
			setTimeout(function () {
				modal.style.display = "none";
			}, 600);
		} else if (event.target.id == "save_m") {
			save()
		} else if (event.target.id == "mqtt") {
			if (check_sel("mqtt") == "OFF") {
				 input(true);
				}else{
					input(false);
				}
		} else {
			if (event.target.tagName == "LI" && event.target.id) {
				document.getElementById('wifi_id').value = event.target.id;
				document.getElementById('wifi_pass').value = "";
				document.getElementById('wifi_pass').focus();
				document.getElementById('wifi_mode').options[1].selected = 'true'
			}
			a.style.display = 'none';
		}
	});
	loading.style.opacity = "0";
	loading.style.display = "none";
};
